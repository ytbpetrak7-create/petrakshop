function rozbalit() {
        document.querySelector(".rozbalovaci")
        .classList.toggle("rozbaleno")
    }